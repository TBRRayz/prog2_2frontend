"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var festival_service_1 = require("./festival.service");
//import { FormGroup, FormControl, Validators, FormBuilder, FormsModule, ReactiveFormsModule }  from '@angular/forms';
var FestivalListComponent = (function () {
    /*
    addFestivalForm: FormGroup;
    name = new FormControl('', Validators.required);
    location = new FormControl('', Validators.required);
    genre = new FormControl('', Validators.required);
    age = new FormControl('', Validators.required);
    date = new FormControl('', Validators.required);
     
    festivals = [];
    isLoading = true;
         
    festival = {};
    isEditing = false;
   */
    function FestivalListComponent(_festivalService) {
        this._festivalService = _festivalService;
        this.pageTitle = 'Festival list';
    }
    FestivalListComponent.prototype.add = function (name, location, genre, age, date) {
        var _this = this;
        name = name.trim();
        location = location.trim();
        genre = genre.trim();
        age = age.trim();
        date = date.trim();
        if (!name || !location || !genre) {
            return;
        }
        this._festivalService.create(name, location, genre, age, date)
            .then(function (festival) {
            _this.festivalen.push(festival);
            _this.festival = null;
        });
    };
    FestivalListComponent.prototype.delete = function (hero) {
        var _this = this;
        this._festivalService
            .delete(hero._id)
            .then(function () {
            _this.festivalen = _this.festivalen.filter(function (h) { return h !== hero; });
            if (_this.festival === hero) {
                _this.festival = null;
            }
        });
    };
    FestivalListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._festivalService.getFestivals()
            .subscribe(function (festivalen) { return _this.festivalen = festivalen; }, function (error) { return _this.errorMessage = error; });
        console.log(this.festivalen);
    };
    return FestivalListComponent;
}());
FestivalListComponent = __decorate([
    core_1.Component({
        selector: 'pm-festivals',
        moduleId: module.id,
        templateUrl: 'festivals-list.component.html',
        styleUrls: ['festivals-list.component.css']
    }),
    __metadata("design:paramtypes", [festival_service_1.FestivalService])
], FestivalListComponent);
exports.FestivalListComponent = FestivalListComponent;
//# sourceMappingURL=festivals-list.component.js.map