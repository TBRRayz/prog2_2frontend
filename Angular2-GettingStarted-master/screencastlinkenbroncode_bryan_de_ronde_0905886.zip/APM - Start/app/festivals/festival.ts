export interface IFestival{
    _id: string;
    Festival: string;
    Location: string;
    Genre: string;
    age: string;
    date: string;
}